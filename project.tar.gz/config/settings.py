"""
settings.py — главный файл настроек Django-проекта.
Здесь мы говорим Django, как должен работать наш сайт.
"""

import os
from pathlib import Path

# BASE_DIR — это корневая папка нашего проекта.
# Path(__file__).resolve().parent.parent означает:
# берём путь к текущему файлу (settings.py),
# поднимаемся на две папки вверх — это и есть корень проекта.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECRET_KEY — секретный ключ для шифрования.
# В реальном проекте его НЕЛЬЗЯ хранить в коде!
# Для разработки подойдёт, для продакшена нужно вынести в переменные окружения.
SECRET_KEY = 'django-insecure-your-secret-key-here'

# DEBUG — режим отладки.
# True — показываем подробные ошибки (только для разработки!)
# False — показываем стандартную страницу 404/500 (для продакшена)
DEBUG = True

# ALLOWED_HOSTS — список доменов, на которых работает сайт.
# Пустой список = только localhost (для разработки)
ALLOWED_HOSTS = []

# INSTALLED_APPS — список всех приложений в проекте.
# Django поставляется со встроенными приложениями:
# - admin: панель администратора
# - auth: система регистрации и авторизации
# - contenttypes: для работы с типами данных
# - sessions: для хранения сессий пользователей
# - messages: для вывода уведомлений
# - staticfiles: для работы со статическими файлами (CSS, JS)
#
# 'main' — это НАШЕ приложение, которое мы создали.
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'main',  # Наше приложение
]

# MIDDLEWARE — это "прослойки", которые обрабатывают каждый запрос.
# Они работают как конвейер: запрос проходит через них по порядку.
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',  # Защита от атак
    'django.contrib.sessions.middleware.SessionMiddleware',  # Работа с сессиями
    'django.middleware.common.CommonMiddleware',  # Общие настройки
    'django.middleware.csrf.CsrfViewMiddleware',  # Защита от CSRF-атак
    'django.contrib.auth.middleware.AuthenticationMiddleware',  # Авторизация
    'django.contrib.messages.middleware.MessageMiddleware',  # Уведомления
    'django.middleware.clickjacking.XFrameOptionsMiddleware',  # Защита от кликджекинга
]

# ROOT_URLCONF — путь к файлу с основными маршрутами (URL-адресами).
ROOT_URLCONF = 'config.urls'

# TEMPLATES — настройки шаблонов (HTML-страниц).
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        # 'DIRS': [] — здесь можно добавить дополнительные папки с шаблонами
        'DIRS': [],
        'APP_DIRS': True,  # True — Django будет искать шаблоны в папке templates каждого приложения
        'OPTIONS': {
            'context_processors': [
                # Это функции, которые добавляют переменные во все шаблоны
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'main.context_processors.site_context',  # Наш собственный контекстный процессор
            ],
        },
    },
]

# WSGI_APPLICATION — точка входа для WSGI-серверов (для продакшена)
WSGI_APPLICATION = 'config.wsgi.application'

# DATABASES — настройки базы данных.
# По умолчанию используется SQLite — лёгкая файловая база данных.
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',  # Файл базы данных в корне проекта
    }
}

# AUTH_PASSWORD_VALIDATORS — валидаторы паролей.
# Проверяют, что пароль достаточно сложный.
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
        # Не должен быть похож на имя пользователя
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        # Минимальная длина (по умолчанию 8 символов)
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
        # Не должен быть в списке самых частых паролей
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
        # Не должен состоять только из цифр
    },
]

# LANGUAGE_CODE — язык сайта
LANGUAGE_CODE = 'ru-ru'

# TIME_ZONE — часовой пояс
TIME_ZONE = 'Europe/Moscow'

# Включить интернационализацию (поддержку разных языков)
USE_I18N = True

# Включить поддержку часовых поясов
USE_TZ = True

# STATIC_URL — URL-адрес для статических файлов (CSS, JS, изображения)
STATIC_URL = 'static/'
# STATICFILES_DIRS — дополнительные папки со статическими файлами
STATICFILES_DIRS = [BASE_DIR / 'main/static']

# MEDIA_URL и MEDIA_ROOT — для загружаемых пользователями файлов (аватары, изображения курсов)
MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'

# DEFAULT_AUTO_FIELD — тип поля для автоматических ID в моделях
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Настройки авторизации
LOGIN_URL = '/accounts/login/'  # Куда перенаправлять неавторизованных пользователей
LOGIN_REDIRECT_URL = '/'  # Куда перенаправлять после входа
LOGOUT_REDIRECT_URL = '/'  # Куда перенаправлять после выхода